package com.example.meritcalculation;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Spinner spBahasaMelayu, spBahasaEnglish, spMath, spSejarah;
    EditText etMarkahKokurikulum;
    Button btnKira;
    TextView tvResult;

    String[] gredList = {"Pilih Gred", "A+", "A", "A-", "B+", "B", "C+", "C", "D", "E", "G"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Link UI
        spBahasaMelayu = findViewById(R.id.spBahasaMelayu);
        spBahasaEnglish = findViewById(R.id.spBahasaEnglish);
        spMath = findViewById(R.id.spMath);
        spSejarah = findViewById(R.id.spSejarah);
        etMarkahKokurikulum = findViewById(R.id.etMarkahKokurikulum);
        btnKira = findViewById(R.id.btnKira);
        tvResult = findViewById(R.id.tvResult);

        // Set adapter for spinners
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, gredList);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spBahasaMelayu.setAdapter(adapter);
        spBahasaEnglish.setAdapter(adapter);
        spMath.setAdapter(adapter);
        spSejarah.setAdapter(adapter);

        // Button click
        btnKira.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // --- MODIFICATION START ---
                // StringBuilder to build our error message
                StringBuilder errorMessages = new StringBuilder();
                boolean hasError = false;

                // 1. Check if all grades are selected
                if (spBahasaMelayu.getSelectedItemPosition() == 0 ||
                        spBahasaEnglish.getSelectedItemPosition() == 0 ||
                        spMath.getSelectedItemPosition() == 0 ||
                        spSejarah.getSelectedItemPosition() == 0) {
                    errorMessages.append("Sila pilih semua gred subjek!");
                    hasError = true;
                }

                // 2. Check co-curricular marks
                int markahKoko = 0;
                String kokoText = etMarkahKokurikulum.getText().toString();
                if (!kokoText.isEmpty()) {
                    markahKoko = Integer.parseInt(kokoText);
                    if (markahKoko < 0 || markahKoko > 10) {
                        // If there was a previous error, add a newline
                        if (hasError) {
                            errorMessages.append("\n");
                        }
                        errorMessages.append("Markah koko mesti antara 0 hingga 10!");
                        hasError = true;
                    }
                } else {
                    // Assuming co-curricular marks are mandatory
                    if (hasError) {
                        errorMessages.append("\n");
                    }
                    errorMessages.append("Sila masukkan markah kokurikulum!");
                    hasError = true;
                }


                // 3. If there are any errors, show the Toast and stop
                if (hasError) {
                    Toast.makeText(MainActivity.this, errorMessages.toString(), Toast.LENGTH_LONG).show();
                    return; // Stop the calculation
                }
                // --- MODIFICATION END ---


                // Ambil markah ikut gred
                int bm = getMark(spBahasaMelayu);
                int bi = getMark(spBahasaEnglish);
                int math = getMark(spMath);
                int sejarah = getMark(spSejarah);

                // Simpan semua gred untuk kira special case
                String gBM = spBahasaMelayu.getSelectedItem().toString();
                String gBI = spBahasaEnglish.getSelectedItem().toString();
                String gMath = spMath.getSelectedItem().toString();
                String gSej = spSejarah.getSelectedItem().toString();

                String[] allGrades = {gBM, gBI, gMath, gSej};

                // Purata subjek akademik (/100)
                double academicAverage = (bm + bi + math + sejarah) / 4.0;

                // Convert koko (0–10) → (/100)
                double kokoPercent = markahKoko * 10.0;

                // Final merit (/100) → 90% akademik + 10% koko
                double finalScore = (academicAverage * 0.9) + (kokoPercent * 0.1);

                // 🔥 Special normalize case: kalau semua A+ kecuali satu A solid
                int countAplus = 0, countA = 0;
                for (String g : allGrades) {
                    if (g.equals("A+")) countAplus++;
                    else if (g.equals("A")) countA++;
                }

                if (countAplus == 3 && countA == 1 && finalScore < 100) {
                    finalScore = 99.9;
                }

                // Clear previous results before showing new ones
                tvResult.setText("");

                tvResult.setText(
                        "Purata Akademik (/100): " + String.format("%.2f", academicAverage) +
                                "\nMarkah Kokurikulum (/10): " + markahKoko +
                                "\nJumlah Merit (/100): " + String.format("%.2f", finalScore)
                );
            }
        });
    }

    // Convert gred → markah standard (/100)
    private int getMark(Spinner spinner) {
        String gred = spinner.getSelectedItem().toString();
        switch (gred) {
            case "A+": return 100;  // 90–100
            case "A":  return 85;   // 80–89
            case "A-": return 77;   // 75–79
            case "B+": return 72;   // 70–74
            case "B":  return 67;   // 65–69
            case "C+": return 62;   // 60–64
            case "C":  return 55;   // 50–59
            case "D":  return 47;   // 45–49
            case "E":  return 42;   // 40–44
            case "G":  return 20;   // 0–39
            default:   return 0;
        }
    }
}
